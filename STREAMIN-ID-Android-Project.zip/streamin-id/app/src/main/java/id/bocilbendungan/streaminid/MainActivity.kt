package id.bocilbendungan.streaminid

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val requestCapture = 901
    private val requestImage = 902
    private val requestMedia = 903
    private lateinit var status: TextView
    private lateinit var sourceList: LinearLayout
    private lateinit var recordButton: Button
    private var recording = false
    private var paused = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 14f, color: Int = Color.WHITE): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { action() }
    }
    private fun panel(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(Color.rgb(29,33,40))
        addView(text(title, 14f, Color.rgb(170,190,205)))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(17,20,25)); setPadding(dp(8),dp(6),dp(8),dp(6)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.rgb(24,28,34)); setPadding(dp(12),0,dp(12),0) }
        top.addView(text("●  STREAMIN ID", 18f), LinearLayout.LayoutParams(0, dp(44), 1f))
        top.addView(text("STUDIO • ANDROID", 12f, Color.LTGRAY))
        root.addView(top)

        val workspace = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = panel("SCENES")
        val sceneName = text("●  Scene 1", 14f); sceneName.setPadding(dp(6),dp(12),0,dp(12)); left.addView(sceneName)
        left.addView(button("＋ Tambah Scene") { addSourceLabel("Scene baru") })
        workspace.addView(left, LinearLayout.LayoutParams(dp(150), -1))

        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6),dp(6),dp(6),dp(6)) }
        val preview = FrameLayout(this).apply { setBackgroundColor(Color.rgb(8,10,13)) }
        val previewText = TextView(this).apply {
            text = "PREVIEW\n\nArea pratinjau studio\nTambahkan Teks, Gambar/Foto, atau Sumber Media dari panel Sources."
            gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; textSize = 16f; setTextColor(Color.rgb(190,200,210))
        }
        preview.addView(previewText, FrameLayout.LayoutParams(-1,-1))
        center.addView(preview, LinearLayout.LayoutParams(-1,0,1f))
        status = text("● SIAP MEREKAM  •  Simpan ke Movies/STREAMIN ID", 12f, Color.rgb(53,208,127))
        center.addView(status, LinearLayout.LayoutParams(-1, dp(32)))
        workspace.addView(center, LinearLayout.LayoutParams(0,-1,1f))

        val right = panel("SOURCES")
        sourceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(sourceList)
        right.addView(button("📷 Webcam") { addSourceLabel("Webcam: butuh kamera/USB kompatibel") })
        right.addView(button("🔤 Teks") { addTextSource() })
        right.addView(button("🖼 Gambar/Foto") { pickFile("image/*", requestImage) })
        right.addView(button("🎞 Sumber Media") { pickFile("video/*", requestMedia) })
        workspace.addView(right, LinearLayout.LayoutParams(dp(210), -1))
        root.addView(workspace, LinearLayout.LayoutParams(-1,0,1f))

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.rgb(24,28,34)); setPadding(dp(6),dp(4),dp(6),dp(4)) }
        val mixer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8),0,dp(8),0) }
        mixer.addView(text("AUDIO MIXER", 12f, Color.LTGRAY))
        mixer.addView(text("Mic / Audio perangkat • izin sistem diperlukan", 11f, Color.GRAY))
        bottom.addView(mixer, LinearLayout.LayoutParams(0,dp(62),1f))
        bottom.addView(button("Transisi: Fade") { Toast.makeText(this,"Transisi Fade dipilih",Toast.LENGTH_SHORT).show() })
        recordButton = button("● MULAI REKAM") { startCapture() }
        bottom.addView(recordButton)
        bottom.addView(button("■ STOP") { stopCapture() })
        root.addView(bottom)
        setContentView(root)
    }

    private fun addSourceLabel(label: String) {
        sourceList.addView(text("• $label", 12f).apply { setPadding(dp(3),dp(5),dp(3),dp(5)) })
    }
    private fun addTextSource() {
        val input = EditText(this).apply { hint = "Tulis teks untuk sumber"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        android.app.AlertDialog.Builder(this).setTitle("Sumber Teks").setView(input)
            .setPositiveButton("Tambah") { _, _ -> if (input.text.isNotBlank()) addSourceLabel("Teks: ${input.text}") }
            .setNegativeButton("Batal", null).show()
    }
    private fun pickFile(type: String, code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); this.type = type }
        startActivityForResult(i, code)
    }
    @Deprecated("legacy picker callback for compact prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val svc = Intent(this, RecordingService::class.java).apply {
                action = RecordingService.ACTION_START
                putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode)
                putExtra(RecordingService.EXTRA_DATA, data)
            }
            startForegroundService(svc)
            recording = true; paused = false; recordButton.text = "● SEDANG REKAM"
            status.text = "● REC AKTIF • Hasil akan disimpan ke Movies/STREAMIN ID"
        } else if (resultCode == RESULT_OK && data?.data != null && (requestCode == requestImage || requestCode == requestMedia)) {
            val uri: Uri = data.data!!
            val name = queryName(uri) ?: if (requestCode == requestImage) "Gambar dipilih" else "Media dipilih"
            addSourceLabel((if (requestCode == requestImage) "Gambar: " else "Media: ") + name)
            Toast.makeText(this, "Dipilih: $name (prototipe: belum dirender ke video)", Toast.LENGTH_LONG).show()
        }
    }
    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (_: Exception) { null }

    private fun startCapture() {
        if (recording) { Toast.makeText(this,"Rekaman sedang berjalan",Toast.LENGTH_SHORT).show(); return }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
    }
    private fun stopCapture() {
        if (!recording) { Toast.makeText(this,"Belum ada rekaman aktif",Toast.LENGTH_SHORT).show(); return }
        startService(Intent(this, RecordingService::class.java).setAction(RecordingService.ACTION_STOP))
        recording = false; paused = false; recordButton.text = "● MULAI REKAM"
        status.text = "✓ Rekaman dihentikan • cek folder Movies/STREAMIN ID"
    }
}
