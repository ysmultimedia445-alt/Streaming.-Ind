package id.bocilbendungan.streaminid

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Environment
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingService : Service() {
    companion object {
        const val ACTION_START = "id.bocilbendungan.streaminid.START"
        const val ACTION_STOP = "id.bocilbendungan.streaminid.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL = "streamin_recording"
        private const val NOTIFICATION_ID = 45
    }
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var outputFile: File? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording(intent)
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }
    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL,"STREAMIN ID recording",NotificationManager.IMPORTANCE_LOW))
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setContentTitle("STREAMIN ID sedang merekam").setContentText("Rekaman layar aktif").setSmallIcon(android.R.drawable.presence_video_online).build()
        else Notification.Builder(this).setContentTitle("STREAMIN ID sedang merekam").setContentText("Rekaman layar aktif").setSmallIcon(android.R.drawable.presence_video_online).build()
    }
    private fun startRecording(intent: Intent) {
        startForeground(NOTIFICATION_ID, notification())
        try {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, ActivityResultCodes.OK)
            val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA) as? Intent
            if (data == null) { stopSelf(); return }
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
            var width = metrics.widthPixels; var height = metrics.heightPixels
            if (width % 2 != 0) width--; if (height % 2 != 0) height--
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "STREAMIN ID")
            if (!dir.exists()) dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            outputFile = File(dir, "Rekaman_$stamp.mp4")
            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            recorder!!.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(width, height)
                setVideoFrameRate(30)
                setVideoEncodingBitRate(4_000_000)
                setOutputFile(outputFile!!.absolutePath)
                prepare()
            }
            display = projection!!.createVirtualDisplay("STREAMIN-ID-Capture", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder!!.surface, null, null)
            recorder!!.start()
        } catch (e: Exception) {
            stopRecording()
        }
    }
    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) { }
        try { display?.release() } catch (_: Exception) { }
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        recorder = null; display = null; projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    override fun onDestroy() { if (recorder != null) stopRecording(); super.onDestroy() }
}
private object ActivityResultCodes { const val OK = -1 }
