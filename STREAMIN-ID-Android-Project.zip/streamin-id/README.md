# STREAMIN ID — Android prototype

A lightweight landscape studio UI prototype inspired by the user's OBS reference. The prototype includes a real Android screen-recording path using MediaProjection and saves MP4 files in the app's Movies/STREAMIN ID folder (inside app-specific external storage). It does not contain streaming controls.

## Included in this prototype
- Landscape studio layout with Scenes, Sources, audio-mixer area, transition button, and record/stop controls.
- Sources menu restricted to Webcam, Text, Image/Photo, and Media Source.
- Screen recording request via Android's system permission dialog; H.264 MP4 at 30 FPS target.
- Recording files saved under: `Android/data/id.bocilbendungan.streaminid/files/Movies/STREAMIN ID/` (path may be hidden by some file managers).

## Important limitations of this first prototype
- This is a starter project, not a finished OBS replacement.
- The record engine captures the Android screen. It does not yet composite selected webcam/text/image/media into the recorded output like OBS does.
- Text and file sources currently appear in the Sources list; image/video preview compositing is not implemented yet.
- USB webcam support depends on Android device/USB camera compatibility and is not implemented in this prototype.
- Pause/resume, audio mixing, and full scene composition are not implemented yet.
- Please test on a spare/compatible device before relying on it for important recordings.

## Build an APK with Android Studio
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK (17 recommended; newer supported versions may work).
2. Open this `streamin-id` folder as an existing project.
3. Allow Gradle to sync and download Android Gradle Plugin dependencies.
4. Choose **Build > Build APK(s)**.
5. The debug APK will normally appear at `app/build/outputs/apk/debug/app-debug.apk`.

No Android SDK or Gradle executable was available in the environment where this source bundle was prepared, so an APK could not be built or tested here.
