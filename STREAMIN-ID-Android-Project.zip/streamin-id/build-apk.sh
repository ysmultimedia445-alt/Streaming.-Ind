#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle tidak ditemukan. Buka folder ini di Android Studio, tunggu Gradle Sync, lalu pilih Build > Build APK(s)." >&2
  exit 1
fi
gradle :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
